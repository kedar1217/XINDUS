package com.example.demo.service;

import com.example.demo.model.WishlistItem;

import java.util.List;

public interface WishlistService {
    List<WishlistItem> getUserWishlist(String username);
    WishlistItem createWishlistItem(String username, WishlistItem wishlistItem);
    void deleteWishlistItem(String username, Long id);
}
