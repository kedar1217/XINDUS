package com.example.demo.service;

import com.example.demo.model.WishlistItem;
import com.example.demo.repository.WishlistRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WishlistServiceImpl implements WishlistService {

    private final WishlistRepository wishlistRepository;

    @Autowired
    public WishlistServiceImpl(WishlistRepository wishlistRepository) {
        this.wishlistRepository = wishlistRepository;
    }

    @Override
    public List<WishlistItem> getUserWishlist(String username) {
        // Implement logic to retrieve user's wishlist from repository
        return wishlistRepository.findByUsername(username);
    }

    @Override
    public WishlistItem createWishlistItem(String username, WishlistItem wishlistItem) {
        wishlistItem.setUsername(username);
        // Implement logic to create wishlist item in repository
        return wishlistRepository.save(wishlistItem);
    }

    @Override
    public void deleteWishlistItem(String username, Long id) {
        // Implement logic to delete wishlist item from repository
        wishlistRepository.deleteByIdAndUsername(id, username);
    }
}
