package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import com.example.demo.model.WishlistItem;
import com.example.demo.service.WishlistService;

import java.util.List;

@RestController
@RequestMapping("/wishlist")
public class WishlistController {

    @Autowired
    private WishlistService wishlistService;

    @GetMapping("/items")
    public ResponseEntity<List<WishlistItem>> getAllItems() {
        List<WishlistItem> items = wishlistService.getAllItems();
        return new ResponseEntity<>(items, HttpStatus.OK);
    }

    @PostMapping("/items")
    public ResponseEntity<WishlistItem> addItem(@RequestBody WishlistItem item, Authentication authentication) {
        WishlistItem newItem = wishlistService.addItem(item, authentication);
        return new ResponseEntity<>(newItem, HttpStatus.CREATED);
    }

    @DeleteMapping("/items/{id}")
    public ResponseEntity<Void> deleteItem(@PathVariable Long id, Authentication authentication) {
        wishlistService.deleteItem(id, authentication);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
